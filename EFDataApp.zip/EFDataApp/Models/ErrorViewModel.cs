using System;

namespace EFDataApp.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; } // ��� ������������
        public string Log { get; set; }
        public string Pasiword { get; set; }
    }
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
